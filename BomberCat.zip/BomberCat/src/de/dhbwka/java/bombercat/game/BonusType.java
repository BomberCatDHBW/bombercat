package de.dhbwka.java.bombercat.game;

public enum BonusType {
	SpeedUp, ExplosionSize, BombAmount
}
