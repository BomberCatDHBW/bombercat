var logServerMessages = false;
var logSendMessages = false;

var serverIP = "localhost";
//var serverIP = "172.16.53.248";

var mainColorR = 204;
var mainColorG = 0;
var mainColorB = 255;