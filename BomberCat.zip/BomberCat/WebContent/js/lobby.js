function Lobby() {
	this.name = "";
	this.players = new Array();
	this.leader = "";
}