package de.dhbwka.java.bombercat;

public enum FieldType {
	Empty, Destructible, Indestructible
}
